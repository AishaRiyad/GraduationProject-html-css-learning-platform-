// ===================== AI CONFIG =====================

const EvalMode = {
  CLASSIC: "classic",
  ML: "ml", // للمرحلة القادمة
};

// helper: get winner (same logic as in game.js, but local copy)
function aiGetWinner(boardArr) {
  const LINES = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];
  for (const [a, b, c] of LINES) {
    if (
      boardArr[a] !== "" &&
      boardArr[a] === boardArr[b] &&
      boardArr[b] === boardArr[c]
    ) {
      return boardArr[a]; // "X" or "O"
    }
  }
  if (!boardArr.includes("")) return "draw";
  return null;
}

// ===================== CLASSICAL EVALUATION =====================

function evaluateBoardClassic(boardArr, aiPlayer) {
  const winner = aiGetWinner(boardArr);
  const opponent = aiPlayer === "X" ? "O" : "X";

  if (winner === aiPlayer) return 1000;
  if (winner === opponent) return -1000;
  if (winner === "draw") return 0;

  let score = 0;
  const LINES = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];

  // two-in-a-row patterns + center + corners
  LINES.forEach(([a, b, c]) => {
    const line = [boardArr[a], boardArr[b], boardArr[c]];

    const aiCount = line.filter((x) => x === aiPlayer).length;
    const oppCount = line.filter((x) => x === opponent).length;
    const emptyCount = line.filter((x) => x === "").length;

    // AI close to winning
    if (aiCount === 2 && emptyCount === 1) score += 10;

    // Opponent close to winning
    if (oppCount === 2 && emptyCount === 1) score -= 10;
  });

  // center
  if (boardArr[4] === aiPlayer) score += 3;

  // corners
  const corners = [0, 2, 6, 8];
  corners.forEach((idx) => {
    if (boardArr[idx] === aiPlayer) score += 2;
  });

  return score;
}

// ===================== ML EVALUATION (placeholder) =====================
function evaluateBoardML(boardArr, aiPlayer) {

    // features based on board state
    const f = boardArr.map(v => (v==="X"?1:v==="O"?-1:0));

    let score = 0;
    for (let i = 0; i < Weights.length; i++)
        score += Weights[i] * f[i];

    // the ML output doesn't know win/loss rules
    // so we enforce them manually
    const winner = aiGetWinner(boardArr);
    if (winner === aiPlayer) return 1000;
    if (winner === (aiPlayer==="X"?"O":"X")) return -1000;

    return score; // ML score
}


// ===================== MINIMAX + ALPHA-BETA =====================

function minimax(boardArr, depth, alpha, beta, maximizingPlayer, aiPlayer, evalMode) {
  const winner = aiGetWinner(boardArr);
  if (
    depth === 0 ||
    winner === "X" ||
    winner === "O" ||
    winner === "draw"
  ) {
    if (evalMode === EvalMode.ML) {
      return evaluateBoardML(boardArr, aiPlayer);
    } else {
      return evaluateBoardClassic(boardArr, aiPlayer);
    }
  }

  const opponent = aiPlayer === "X" ? "O" : "X";

  if (maximizingPlayer) {
    let maxEval = Number.NEGATIVE_INFINITY;
    for (let i = 0; i < 9; i++) {
      if (boardArr[i] === "") {
        boardArr[i] = aiPlayer;
        const evalValue = minimax(
          boardArr,
          depth - 1,
          alpha,
          beta,
          false,
          aiPlayer,
          evalMode
        );
        boardArr[i] = "";
        if (evalValue > maxEval) maxEval = evalValue;
        if (evalValue > alpha) alpha = evalValue;
        if (beta <= alpha) break; // beta cut-off
      }
    }
    return maxEval;
  } else {
    let minEval = Number.POSITIVE_INFINITY;
    for (let i = 0; i < 9; i++) {
      if (boardArr[i] === "") {
        boardArr[i] = opponent;
        const evalValue = minimax(
          boardArr,
          depth - 1,
          alpha,
          beta,
          true,
          aiPlayer,
          evalMode
        );
        boardArr[i] = "";
        if (evalValue < minEval) minEval = evalValue;
        if (evalValue < beta) beta = evalValue;
        if (beta <= alpha) break; // alpha cut-off
      }
    }
    return minEval;
  }
}

// ===================== PUBLIC API FOR GAME =====================

function getBestMoveWithScores(boardArr, aiPlayer, maxDepth, evalMode) {
  const movesInfo = [];
  let bestScore = Number.NEGATIVE_INFINITY;
  let bestMove = null;

  for (let i = 0; i < 9; i++) {
    if (boardArr[i] === "") {
      boardArr[i] = aiPlayer;
      const score = minimax(
        boardArr,
        maxDepth - 1,
        Number.NEGATIVE_INFINITY,
        Number.POSITIVE_INFINITY,
        false,
        aiPlayer,
        evalMode === "ml" ? EvalMode.ML : EvalMode.CLASSIC
      );
      boardArr[i] = "";

      movesInfo.push({ index: i, score });

      if (score > bestScore) {
        bestScore = score;
        bestMove = i;
      }
    }
  }

  return { bestMove, bestScore, movesInfo };
}
