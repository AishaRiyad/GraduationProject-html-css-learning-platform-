/**********************************************************
 * MACHINE LEARNING - PERCEPTRON TRAINING (NO LIBRARIES)
 **********************************************************/

let Weights = []; // trained weights will be stored here


// ======================= CSV READER =======================

async function loadCSV(path) {
    const data = await fetch(path).then(r => r.text());
    const lines = data.trim().split("\n");

    // first row assumed header
    const rows = lines.slice(1).map(row => row.split(",").map(Number));

    return rows; // matrix of numbers
}


/**********************************************************
 * 🔥 FEATURE EXTRACTION (Improved 15 features instead of 9)
 **********************************************************/

function extractFeatures(boardArr, aiPlayer = "X") {

    const opponent = aiPlayer === "X" ? "O" : "X";

    // 1–9 board numeric features (original)
    const cells = boardArr.map(v => v === "X" ? 1 : v === "O" ? -1 : 0);

    // Feature 10 → Center control (Strong move in TicTacToe)
    const center = boardArr[4] === aiPlayer ? 1 :
                   boardArr[4] === opponent ? -1 : 0;

    // Feature 11 & 12 → Corner control bonus
    const corners = [0,2,6,8];
    let aiCorners = 0, oppCorners = 0;
    corners.forEach(i=>{
        if(boardArr[i] === aiPlayer) aiCorners++;
        if(boardArr[i] === opponent) oppCorners++;
    });

    // Feature 13 & 14 → Two-in-row detection
    const LINES = [
        [0,1,2],[3,4,5],[6,7,8],
        [0,3,6],[1,4,7],[2,5,8],
        [0,4,8],[2,4,6]
    ];

    let twoAI = 0, twoOPP = 0;
    LINES.forEach(([a,b,c])=>{
        let line = [boardArr[a], boardArr[b], boardArr[c]];
        if(line.filter(x=>x===aiPlayer).length===2 && line.includes("")) twoAI++;
        if(line.filter(x=>x===opponent).length===2 && line.includes("")) twoOPP++;
    });

    // Feature 15 → Aggression score gives push towards winning move
    let nearWinScore = (twoAI * 3) - (twoOPP * 2);

    return [...cells, center, aiCorners, oppCorners, twoAI, twoOPP, nearWinScore];
}


/**********************************************************
 * MACHINE LEARNING TRAINING (Improved with new features)
 **********************************************************/

async function trainModel(epochs = 2000, lr = 0.18) {

    const dataset = await loadCSV("tictactoe_dataset.csv");

    // NEW FEATURE COUNT — instead of dataset size
    const sampleBoard = ["","","","","","","","",""];
    const featureCount = extractFeatures(sampleBoard).length;   // = 15 features now

    Weights = new Array(featureCount).fill(0);   // init weights


    for (let ep = 1; ep <= epochs; ep++) {
        let correct = 0;

        for (let row of dataset) {

            // convert dataset row → board
            const board = row.slice(0,9).map(v => v===1?"X":v===-1?"O":"");
            const label = row[row.length - 1]; // +1 or -1

            const x = extractFeatures(board, "X");
            const y_hat = predict(x);

            // Perceptron update
            if (y_hat !== label) {
                for (let i = 0; i < x.length; i++)
                    Weights[i] += lr * label * x[i];
            } else correct++;
        }

        console.log(`Epoch ${ep} accuracy = ${(correct/dataset.length*100).toFixed(2)}%`);
    }

    saveWeights();
}


/**********************************************************
 * PREDICTION — unchanged logic but now stronger due to features
 **********************************************************/

function predict(features) {
    let sum = 0;
    for (let i = 0; i < features.length; i++)
        sum += features[i] * Weights[i];

    return sum >= 0 ? +1 : -1;
}


/**********************************************************
 * SAVE & LOAD MODEL (unchanged — kept as requested)
 **********************************************************/

function saveWeights() {
    const blob = new Blob([JSON.stringify(Weights)], { type: "application/json" });
    const a = document.createElement("a");

    a.href = URL.createObjectURL(blob);
    a.download = "weights.json";
    a.click();

    alert("Training complete. weights.json downloaded.");
}

async function loadWeights() {
    const file = await fetch("weights.json").then(r => r.json());
    Weights = file;
    alert("Model loaded successfully.");
}


// ============== BUTTON EVENTS (as original — unchanged) ==============

document.getElementById("trainBtn").onclick = () => trainModel(50, 0.1);
document.getElementById("loadBtn").onclick = () => loadWeights();
