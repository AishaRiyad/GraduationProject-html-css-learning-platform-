// ===================== GLOBAL GAME STATE =====================

let board = Array(9).fill(""); // "X", "O", or ""
let currentPlayer = "X";
let humanPlayer = "X"; // default
let aiPlayer = "O";

// عند تغيير اختيار اللاعب من القائمة
document.getElementById("playerSelect").addEventListener("change", (e) => {
    // 🔥 تصحيح اختيار اللاعب (بدون حذف أي شيء من الكود الأصلي)
    humanPlayer = e.target.value.includes("O") ? "O" : "X";
    aiPlayer = humanPlayer === "X" ? "O" : "X";
    
    startNewGame();
 // إعادة ضبط لوحة اللعب تلقائياً
    
  
});

let gameOver = false;

const boardElement = document.getElementById("board");
const statusElement = document.getElementById("status");
const moveInfoElement = document.getElementById("moveInfo");

const playerSelect = document.getElementById("playerSelect");
const difficultySelect = document.getElementById("difficultySelect");
const evalSelect = document.getElementById("evalSelect");
const newGameBtn = document.getElementById("newGameBtn");

// depths for difficulties
const DIFFICULTY_DEPTH = {
  easy: 1,
  medium: 3,
  hard: 6,
};

// ===================== INIT BOARD UI =====================

function createBoardUI() {
  boardElement.innerHTML = "";
  for (let i = 0; i < 9; i++) {
    const cell = document.createElement("div");
    cell.className = "cell";
    cell.dataset.index = i;
    cell.addEventListener("click", onCellClick);
    boardElement.appendChild(cell);
  }
}

function renderBoard() {
  const cells = document.querySelectorAll(".cell");
  cells.forEach((cell, idx) => {
    cell.textContent = board[idx];
    if (gameOver || board[idx] !== "" || currentPlayer !== humanPlayer) {
      cell.classList.add("disabled");
    } else {
      cell.classList.remove("disabled");
    }
  });
}

// ===================== GAME LOGIC HELPERS =====================

const WIN_LINES = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6],
];

function getWinner(boardArr) {
  for (const [a, b, c] of WIN_LINES) {
    if (
      boardArr[a] !== "" &&
      boardArr[a] === boardArr[b] &&
      boardArr[b] === boardArr[c]
    ) {
      return boardArr[a]; // "X" or "O"
    }
  }
  if (!boardArr.includes("")) return "draw";
  return null; // game not finished
}

// ===================== TURN HANDLING =====================

function onCellClick(e) {
  if (gameOver) return;
  if (currentPlayer !== humanPlayer) return;

  const index = parseInt(e.currentTarget.dataset.index, 10);
  if (board[index] !== "") return;

  board[index] = humanPlayer;
  afterMove();
}

function afterMove() {
  renderBoard();

  const status = getWinner(board);
  if (status === "X" || status === "O") {
    gameOver = true;
    statusElement.textContent = `Game over: ${status} wins!`;
    moveInfoElement.textContent = "";
    return;
  } else if (status === "draw") {
    gameOver = true;
    statusElement.textContent = "Game over: Draw!";
    moveInfoElement.textContent = "";
    return;
  }

  currentPlayer = currentPlayer === "X" ? "O" : "X";
  statusElement.textContent = `Current turn: ${currentPlayer}`;

  renderBoard();

  // AI move if it's AI's turn
  if (!gameOver && currentPlayer === aiPlayer) {
    window.setTimeout(aiMove, 150);
  }
}

function aiMove() {
  const difficulty = difficultySelect.value;
  const depth = DIFFICULTY_DEPTH[difficulty] || 3;
  const evalMode = evalSelect.value || "classic";

  // get best move + debug scores
  const result = getBestMoveWithScores(board, aiPlayer, depth, evalMode);
  const bestIndex = result.bestMove;
  const movesInfo = result.movesInfo;

  if (bestIndex === null || bestIndex === undefined) {
    // no moves, should not happen
    gameOver = true;
    statusElement.textContent = "Game over: No available moves.";
    return;
  }

  board[bestIndex] = aiPlayer;

  // print scores for each considered move
  let infoText = "";
  movesInfo.forEach((m) => {
    infoText += `Move [${m.index}] -> score = ${m.score}\n`;
  });
  moveInfoElement.textContent = infoText.trim();

  afterMove();
}

// ===================== NEW GAME =====================

function startNewGame() {
  board = Array(9).fill("");
  gameOver = false;

  // Read selection correctly
  humanPlayer = playerSelect.value.includes("O") ? "O" : "X";
  aiPlayer = humanPlayer === "X" ? "O" : "X";

  // 🔥 تحديد من يبدأ حسب اختيار اللاعب
  currentPlayer = "X"; // X always starts by game rules

  statusElement.textContent = `Current turn: ${currentPlayer}`;
  moveInfoElement.textContent = "";
  renderBoard();

  // 🔥 إذا اللاعب اختار O → AI يبدأ فوراً
  if (humanPlayer === "O" && currentPlayer === "X") {
    setTimeout(aiMove, 300);
  }
}



// ===================== EVENT BINDING =====================

window.addEventListener("DOMContentLoaded", () => {
  createBoardUI();
  renderBoard();
  startNewGame();
});

newGameBtn.addEventListener("click", () => {
  startNewGame();
});
